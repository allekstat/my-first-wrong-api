<!DOCTYPE html>
<html lang='pt-br'>
    <head>
        <title>USUÁRIOS</title>
    </head>
    <body style='margin: 0; padding: 0; border: 0; box-sizing: border-box; height: 100vh; display: flex;'>
        <main style='flex-grow: 1; display: flex; flex-direction: column; justify-content: center; row-gap: 1rem; margin: 1rem; padding: 1rem; border: 0.1rem ridge silver; border-radius: 0.5rem; align-items: center;'>
            <input type='text' name='' id='nome' placeholder='nome' style='min-width: 20%;'>
            <input type='text' name='' id='email' placeholder='email' style='min-width: 20%;'>
            <input type='password' name='' id='senha' placeholder='senha' style='min-width: 20%;'>
            <input type='button' value='cadastrar' style='min-width: 20%;' onclick='cadastrar()'>
            <input type='button' value='atualizar' disabled style='min-width: 20%;' onclick='atualizar()'>
            <input type='button' value='remover' disabled style='min-width: 20%;' onclick='remover()'>
            <input type='button' value='listar' style='min-width: 20%;' onclick='listar()'>
            <table>
                <thead>
                    <tr>
                        <th>nome</th>
                        <th>email</th>
                        <th>senha</th>
                    </tr>
                </thead>
                <tbody id='tabela'></tbody>
            </table>
        </main>
        <script>
            let usuario_atual;
            function cadastrar()
            {
                const nome = document.getElementById('nome').value;
                const email = document.getElementById('email').value;
                const senha = document.getElementById('senha').value;
                // const tabela = document.getElementById('tabela');
                // tabela.append(nome, '-', email, '-', senha);
                fetch('/api/usuarios', {method: 'POST', body: JSON.stringify({nome, email, senha})});
            }
        </script>
    </body>
</html>