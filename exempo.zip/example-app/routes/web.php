<?php

use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('adm', function () {
    return view('adm');
});


// Route::get('api/usuarios', [UserController::class, 'index']);
// Route::post('api/usuarios', [UserController::class, 'store']);